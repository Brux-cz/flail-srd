# Archiv nepotřebných souborů FLAIL SRD

**Datum archivace:** 2026-01-26
**Důvod:** Čištění projektu od regenerovatelných a historických souborů

## Obsah archivu

### 1. `site/` (16 MB)
- **Typ:** HTML výstup z MkDocs
- **Použití:** Lokální preview (není třeba pro publikaci)
- **Obnovení:** `mkdocs build`

### 2. `venv/` (148 MB)
- **Typ:** Python virtual environment
- **Použití:** Lokální development dependencies
- **Obnovení:**
  ```bash
  python -m venv venv
  source venv/bin/activate
  pip install mkdocs-material mkdocs-static-i18n
  ```

### 3. `translation_source.md` (220 KB)
- **Typ:** Původní monolitický překlad (před rozdělením do docs/cs/)
- **Použití:** Historický reference
- **Hodnota:** Archivní, nahrazeno strukturovanými soubory v docs/cs/

### 4. `TRANSLATION_TODO.md` (4 KB)
- **Typ:** TODO list z testu workflow v1.0-test
- **Použití:** Testovací dokument (test dokončen)
- **Hodnota:** Příklad pro budoucí použití

---

## Obnovení souborů

### Celý archiv:
```bash
tar -xzf archive.tar.gz
```

### Jednotlivé soubory:
```bash
# Pouze translation_source.md
tar -xzf archive.tar.gz archive/translation_source.md
mv archive/translation_source.md .

# Pouze TRANSLATION_TODO.md
tar -xzf archive.tar.gz archive/TRANSLATION_TODO.md
mv archive/TRANSLATION_TODO.md .
```

### Regenerace místo obnovení:
```bash
# site/ - místo obnovení z archivu prostě rebuild:
mkdocs build

# venv/ - místo obnovení z archivu prostě reinstall:
python -m venv venv
source venv/bin/activate
pip install mkdocs-material mkdocs-static-i18n
```

---

## Poznámky

- Projekt zůstává plně funkční bez těchto souborů
- Všechny publikované soubory (docs/cs/) zůstávají nedotčené
- MkDocs konfigurace (mkdocs.yml) a GitHub Actions (.github/workflows/) fungují stejně
- Archiv je komprimovaný (tar.gz) pro úsporu místa

**Celková velikost archivu:** ~164 MB
**Komprimovaná velikost:** ~80 MB (očekáváno)
